﻿namespace OOPLabs1_2_3_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Fraction f1 = new Fraction(1,2);
            Fraction f2 = new Fraction(1,3);

            Console.WriteLine(Fraction.Add(f1, f2));        
        }
    }
}
