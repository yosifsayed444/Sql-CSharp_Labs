﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OOPLabs1_2_3_4
{
    internal class Point
    {
        public int X {  get; set; }
        public int Y { get; set; }

        public int Z { get; set; }


        public void Display()
        {
            Console.WriteLine($"X: {X}, Y: {Y}, Z: {Z}");
        }

        public int CalcDistance(Point p1, Point p2)
        {
            return p1.X - p2.X;
        }
    }

    internal class Fraction
    {
        public decimal Num { get; set; }
        public decimal Den { get; set; }

        public Fraction(int x, int y) {
            Num = x;
            Den = y;
        }
        public void Display()
        {
            Console.WriteLine($"{Num}/{Den}");
        }

        public static decimal Add(Fraction f1 , Fraction f2)
        {
            return ((f1.Den*f2.Num)+(f1.Num*f2.Den))/(f1.Den*f2.Den);
        }
    }
}
