﻿using Lab4;
using System;
using System.Collections;
using System.Collections.Generic;

namespace Lab3
{
    internal class Zoo : IEnumerable<Animal>, IReadOnlyCollection<Animal>
    {
        private readonly List<Animal> animals = new List<Animal>();
        private readonly List<Mammal> mammals = new List<Mammal>();
        private readonly List<Bird> birds = new List<Bird>();

        public IReadOnlyCollection<Mammal> Mammals => mammals;
        public IReadOnlyCollection<Bird> Birds => birds;

        public int Count => animals.Count;

        public void Add(Animal animal)
        {
            animals.Add(animal);
        }

        public void Add(Mammal mammal)
        {
            animals.Add(mammal);
            mammals.Add(mammal);
        }

        public void Add(Bird bird)
        {
            animals.Add(bird);
            birds.Add(bird);
        }

        public IEnumerator<Animal> GetEnumerator()
        {
            return animals.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }


    internal class Animal
    {
        public int Age { get; set; }

        public Animal(int age)
        {
            if (age > 10)
            {
                throw new InvalidAnimalAgeException(
                    "Animal age cannot be more than 10",
                    this
                );
            }

            Age = age;
        }
    }


    internal class Mammal : Animal
    {
        public Mammal(int age) : base(age)
        {
        }
    }


    internal class Bird : Animal
    {
        public Bird(int age) : base(age)
        {
        }
    }


    internal class Lion : Mammal
    {
        public Lion(int age) : base(age)
        {
        }

        public override string ToString()
        {
            return $"this is a lion with age {Age}";
        }
    }


    internal class Elephant : Mammal
    {
        public Elephant(int age) : base(age)
        {
        }

        public override string ToString()
        {
            return $"this is an Elephant with age {Age}";
        }
    }


    internal class Sparrow : Bird
    {
        public Sparrow(int age) : base(age)
        {
        }

        public override string ToString()
        {
            return $"this is a sparrow with age {Age}";
        }
    }


    internal class Piegon : Bird
    {
        public Piegon(int age) : base(age)
        {
        }

        public override string ToString()
        {
            return $"this is a pigeon with age {Age}";
        }
    }
}