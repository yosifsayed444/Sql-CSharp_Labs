﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Linq;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Lab3
{
    internal class PhoneBook
    {
        public Dictionary<int, string> entries = new Dictionary<int, string>();

        public string this[int index]
        {
            get
            {
                if (entries.ContainsKey(index))
                    return entries[index];

                return null;
            }
            set
            {
                entries[index] = value;
            }
        }

        public int this[string name]
        {
            get
            {
                foreach (var entry in entries)
                {
                    if (entry.Value == name)
                        return entry.Key;
                }

                return -1;
            }
            set
            {
                entries[value] = name;
            }
        }
    }
}
