﻿using Lab3;

namespace Lab4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            Zoo zoo = new Zoo();
            zoo.Add(new Lion(2));
            zoo.Add(new Piegon(1));
            zoo.Add(new Sparrow(7));
            zoo.Add(new Elephant(7));
            

            foreach (Animal bird in zoo.Birds)
            {
                Console.WriteLine(bird);
            }
            Console.WriteLine("----------------------");
            foreach(Mammal mammal in zoo.Mammals)
            {
                Console.WriteLine(mammal);
            }
            Console.WriteLine("----------------------");
            foreach (Animal animal in zoo)
            {
                Console.WriteLine(animal);
            }
            PhoneBook phoneBook = new PhoneBook();

            phoneBook[123] = "Youssef";
            phoneBook[456] = "Ahmed";

            Console.WriteLine(phoneBook[123]);          // Youssef
            Console.WriteLine(phoneBook["Ahmed"]);      // 456
        }
    }
}
