﻿using Lab3;
using System;
using System.Collections.Generic;
using System.Text;

namespace Lab4
{
    internal class InvalidAnimalAgeException : Exception
    {
        Animal a;
        public InvalidAnimalAgeException(string msg, Animal a)
        {
            this.a = a;
        }
    }
}
