﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region Collections

            #region ArrayList
            //ArrayList arrayList = new ArrayList();
            //arrayList.Add(1);
            //arrayList.Add("jhkjhk");
            //arrayList.Add(4.7);

            //object obj = arrayList[1]; 
            #endregion

            #region List
            List<int> myList = new List<int>(50);
            //myList.Add(3);
            //myList.Add(5);
            //myList.Add(6);
            //myList.Add(7);

            //int num = myList[0];
            //myList[3] = 10;
            //myList.Insert(1, 4);

            //if(myList.Contains(5))
            //    Console.WriteLine("true");

            //myList.Clear();

            //Console.WriteLine($"Capacity: {myList.Capacity}");
            //Console.WriteLine($"Count: {myList.Count}");

            //foreach (int item in myList)
            //{
            //    Console.WriteLine(item);
            //} 
            #endregion

            #region Dictionary
            //Dictionary<int, string> dic = new Dictionary<int, string>();

            //dic.Add(10, "Ali");
            //dic.Add(20, "Hosam");
            //dic.Add(30, "Amgad");

            //if (! dic.ContainsKey(30))
            //    dic.Add(30, "Test");

            //string name = dic[30];

            //foreach (int key in dic.Keys)
            //{
            //    Console.WriteLine($"Key = {key} \t Value = {dic[key]}");
            //}

            //foreach (KeyValuePair<int, string> item in dic)
            //{
            //    Console.WriteLine($"Key = {item.Key} \t Value = {item.Value}");
            //} 
            #endregion

            //EmployeeList employees = new EmployeeList();
            //employees.Add(new Employee { ID = 1, Name = "Ali" });

            //List<Employee> employees = new List<Employee>()
            //{
            //    new Employee { ID = 1, Name = "Ali"},
            //    new Employee { ID = 2, Name = "Hosam"},
            //    new Employee { ID = 3, Name = "Amgad"},
            //}; 
            #endregion


            #region Exceptions
            try
            {
                Test();
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.WriteLine("Finish");
        }

        private static void Test()
        {
            try
            {
                int x = int.Parse(Console.ReadLine());

                if(x == 0)
                {
                    throw new DivideByZeroException("Please enter a valid number");
                }

                int y = 10 / x;

                int[] arr = { 1, 2, 3 };
                arr[5] = 10;

                Console.WriteLine($"Result: {y}");
            }
            catch (IndexOutOfRangeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine("Close connection");
            }        
        }

        private static void ValidateEmployeeData(Employee emp)
        {
            if (emp.ID > 100)
                throw new InvalidEmployeeDataException("ID must be smaller than 100", emp);
        }
#endregion
    }
}
