﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4
{
    internal class Employee : IComparable<Employee>//,  ICloneable
    {
        public int ID { get; set; }
        public string Name { get; set; }

        //public int CompareTo(object obj)
        //{
        //    //Employee emp = (Employee)obj;

        //    Employee emp = obj as Employee;

        //    if (emp == null)
        //        return 1;

        //    //if (obj is Employee)
        //    //{
        //    //    Employee employee = (Employee)obj;
        //    //}
        //    //else
        //    //    return 1;

        //    //if (this.ID == emp.ID)
        //    //    return 0;

        //    //if (this.ID > emp.ID)
        //    //    return 1;

        //    //return -1;

        //    return this.ID.CompareTo(emp.ID);
        //}

        public int CompareTo(Employee emp)
        {
            return this.ID.CompareTo(emp.ID);
        }

        public override string ToString()
        {
            return $"ID: {ID} \t Name: {Name}";
        }
    }
}
