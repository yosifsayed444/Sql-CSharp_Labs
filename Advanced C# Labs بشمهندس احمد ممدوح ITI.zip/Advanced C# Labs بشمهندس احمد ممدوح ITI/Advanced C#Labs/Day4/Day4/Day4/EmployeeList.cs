﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4
{
    internal class EmployeeList : List<Employee>
    {
        public void Add(Employee emp)
        {
            if(!emp.Name.Contains("S"))
            {
                base.Add(emp);
            }
        }
    }
}
