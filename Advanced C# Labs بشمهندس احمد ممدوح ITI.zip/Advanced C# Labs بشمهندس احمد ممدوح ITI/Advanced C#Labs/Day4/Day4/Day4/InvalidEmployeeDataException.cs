﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4
{
    internal class InvalidEmployeeDataException : Exception
    {
        Employee emp;

        public InvalidEmployeeDataException(string message, Employee emp) : base(message)
        {
            this.emp = emp;
        }
    }
}
