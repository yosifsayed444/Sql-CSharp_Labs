﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5
{
    internal class BBC
    {
        public event Action<object, NewsAddedEventArgs> NewsAdded;

        public void AddNews(string news)
        {
            if (NewsAdded != null)
                NewsAdded(this , new NewsAddedEventArgs { News = news, DateTime = DateTime.Now});
        }
    }

    class NewsAddedEventArgs : EventArgs
    {
        public string News { get; set; }
        public DateTime DateTime { get; set; }
    }
}
