﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5
{
    internal class Journalist
    {
        public event Action<object, NewsAddedEventArgs> InfoCome;

        public void AddInfo(string info)
        {
            if (InfoCome != null)
                InfoCome(this, new NewsAddedEventArgs { News = info, DateTime = DateTime.Now});
        }
    }
}
