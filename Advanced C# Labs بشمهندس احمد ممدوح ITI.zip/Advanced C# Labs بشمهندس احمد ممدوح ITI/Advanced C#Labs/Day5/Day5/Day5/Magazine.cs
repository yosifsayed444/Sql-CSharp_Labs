﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5
{
    internal class Magazine
    {
        public void MsgIsHere(object sender, NewsAddedEventArgs args)
        {
            if (sender is BBC)
                Console.WriteLine($"Magazine from BBC: {args.News}");
            else if(sender is Journalist)
                Console.WriteLine($"Magazine from Journalist: {args.News}");
        }
    }
}
