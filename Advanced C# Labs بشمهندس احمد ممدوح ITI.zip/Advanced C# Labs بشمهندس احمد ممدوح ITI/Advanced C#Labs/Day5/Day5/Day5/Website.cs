﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5
{
    internal class Website
    {
        public Website()
        {
        }

        public Website(BBC bBC)
        {
            bBC.NewsAdded += NewsSent;
        }

        public void NewsSent(object sender, NewsAddedEventArgs args)
        {
            Console.WriteLine($"Website: {args.News}");
        }
    }
}
