﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5
{
    delegate bool MyDelegate(int num);

    internal class Program
    {
        static bool IsEven(int num)
        {
            Console.WriteLine("IsEven");
            return num % 2 == 0;
        }

        static bool IsNegative(int num)
        {
            Console.WriteLine("IsNegative");
            return num < 0;
        }

        static void Display(List<int> list, Predicate<int> filter) //MyDelegate filter)
        {
            foreach (int item in list)
            {
                if (filter(item))
                    Console.WriteLine(item);
            }
        }

        static void Main(string[] args)
        {
            List<int> list = new List<int> { 1, 2, -3, -4, 5, 6, -7, 8, 9 };

            //MyDelegate evenDel = new MyDelegate(IsEven);
            //MyDelegate negDel = new MyDelegate(IsNegative);

            //bool flag = del(5);  //del.Invoke(5);

            //MyDelegate del = IsEven;
            //MyDelegate del = Helper.IsPositive;

            //Helper helper = new Helper();
            //MyDelegate del = helper.IsOdd;

            //Display(list, del);

            //Display(list, IsEven); //Display(list, new MyDelegate(IsEven));

            // Display(list, delegate (int num)
            //{
            //    return num % 2 == 0;
            //});

            // Display(list, num => num % 2 == 0);

            //Func<string> del = () => "hello";
            //Func<string, bool> del = str => str == "iti";

            //Action<int> del = num => Console.WriteLine(num);

            //Action del = () => Console.WriteLine("Hello");

            //Predicate<int> del = IsEven;
            //del += IsNegative;

            //del(2);

            //del += Helper.IsPositive;
            //del -= IsNegative;

            //del(2);

            Magazine magazine = new Magazine();
            BBC bBC = new BBC();
            Journalist journalist = new Journalist();

            bBC.NewsAdded += magazine.MsgIsHere;
            journalist.InfoCome += magazine.MsgIsHere;

           // bBC.AddNews("Zamalek will lose the coming match ISA");

            //Website website = new Website(bBC);
            Website website = new Website();

            //bBC.NewsAdded = website.NewsSent;
            //bBC.NewsAdded = null;

            bBC.AddNews("Al Ahly will win the coming match ISA");
            journalist.AddInfo("Zamalek will lose the coming match ISA");
        }
    }
}
