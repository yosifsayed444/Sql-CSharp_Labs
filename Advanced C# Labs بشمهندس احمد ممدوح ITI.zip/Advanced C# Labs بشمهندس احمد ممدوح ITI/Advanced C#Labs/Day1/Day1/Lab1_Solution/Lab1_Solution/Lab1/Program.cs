﻿namespace Lab1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee();

            emp.Name = "Youssef";
            emp.Salary = 15000;

            emp.AddRule(Rules.Admin);

            emp.display();

            Console.WriteLine(emp.HasRule(Rules.Admin)); // True
            string s = "ali";
            ChangeVal(ref s);
            Console.WriteLine(s);
        }
        public static void ChangeVal(ref string s)
        {
            s = s.ToUpper();
        }
    }
}
    
  