﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab1
{
    internal struct Employee
    {
        public string Name { get; set; }
        public decimal Salary { get; set; }

        public Rules Rule { get; set; }


        public void display()
        {
            Console.WriteLine($"Empdata {Name},{Salary},{Rule}");
        }
        public void AddRule( Rules rule)
        {
            Rule = rule;
        }
        public bool HasRule(Rules rule) {

            return Rule == rule;
        }
    }
}
