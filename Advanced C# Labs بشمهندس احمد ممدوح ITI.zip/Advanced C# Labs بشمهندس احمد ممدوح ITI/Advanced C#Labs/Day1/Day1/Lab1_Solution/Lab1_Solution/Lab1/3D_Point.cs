﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab1
{
    internal class _3D_Point
    {
        public int X {  get; set; }
        public int Y { get; set; }

        public int Z { get; set; }
        public _3D_Point(int x,int y, int z) {
            X = x;
            Y = y;
            Z = z;
        }

        public void Display()
        {
            Console.WriteLine($"cooridantors are ({X},{Y},{Z})");
        }
        public void changeCooridnates(int newX, int newY, int newZ)
        {
            X = newX;
            Y = newY;
            Z = newZ;
        }



    }
}
