﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day1
{
    internal class Employee
    {
        public int ID;

        public Gender gender;

        public Employee()
        {

        }

        public void Test()
        {
            int a;

        }
    }
}
