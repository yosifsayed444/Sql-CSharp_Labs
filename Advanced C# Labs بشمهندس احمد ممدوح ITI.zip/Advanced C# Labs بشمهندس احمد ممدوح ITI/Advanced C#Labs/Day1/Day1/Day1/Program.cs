﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day1
{
    enum Gender
    {
        Male,
        Female
    }

    enum Color
    {
        Red = 1, 
        Green = 2,
        //Ay7aga = 3,
        Blue = 4,
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            #region Enums
            // Gender g = Gender.Female;

            //int x = 5;
            //Employee emp = new Employee();
            //emp.gender = Gender.Female;

            //if (emp.gender == Gender.Female)
            //    ;

            Color c = Color.Red | Color.Green;

            if((c & Color.Red) == Color.Red)
            {
                Console.WriteLine("Contains red");
            }
            else
                Console.WriteLine("Not contains red");

            Console.WriteLine(c);

            #endregion

            #region Structs
            //Complex c1 = new Complex(10);
            ////c1.Real = 10;

            //Test(c1);

            //Console.WriteLine(c1.Real); 
            #endregion

        }

        static void Test(Complex c)
        {
            c.Real = 50;
        }
    }
}
