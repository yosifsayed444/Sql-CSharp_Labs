﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day1
{
    internal struct Complex
    {
        public int Real;
        public int Img;

        public Complex(int real)
        {
            Real = real;
            Img = 10;
        }

        public Complex(int real , int img)
        {
            Real = real;
            Img = img;
        }

        public void Test()
        {
           
        }
    }
}
