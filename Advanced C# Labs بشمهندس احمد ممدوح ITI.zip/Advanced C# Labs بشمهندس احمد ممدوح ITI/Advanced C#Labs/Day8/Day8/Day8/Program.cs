﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day8
{
    internal class Program
    {
        static object Test()
        {
            var e = new { ID = 1, Name = "Ali" };
            return e;
        }

        static IEnumerable<int> Sequence()
        {
            //List<int> list = new List<int>() { 1, 2, 3 };
            //return list;

            yield return 1;

            yield return 2;

            yield return 3;
        }

        static void Main(string[] args)
        {
            #region implicitly typed local variable
            //var x = 5;
            //var s = "kjlkjdklf";
            //var dic = new Dictionary<int, EmployeeData>(); 
            #endregion

            #region Anonyous object
            //var e = new { ID = 1, Name = "Ali" };
            //var b = new { ID = 2, Name = "Hosam", Salary = 3000 };

            //Console.WriteLine(e.ID); 
            #endregion

            #region Extension methods
            //List<int> list = new List<int>() { 1, 2, 3, -4, -5, 6, 7, -8, 9 };

            //IEnumerable<int> newList = list.Filter(x => x > 3);

            //int x = 5;
            //x.PrintMe();    // Extensions.PrintMe(x);

            //string s = "Hello I T I";

            //int num = Extensions.GetumberOfSpaces(s);
            //Extensions.PrintMe(num);

            //Extensions.PrintMe(Extensions.GetumberOfSpaces(Extensions.RemoveCharacter(s, 'a')));
            //s.RemoveCharacter('a').GetumberOfSpaces().PrintMe();

            //s.RemoveCharacter('a'); 
            #endregion

            //IEnumerable<int> enumerable = Sequence();
            //IEnumerator<int> enumerator = enumerable.GetEnumerator();

            //while (enumerator.MoveNext())
            //{
            //    Console.WriteLine(enumerator.Current);
            //}

            //foreach (int item in Sequence())
            //{
            //    Console.WriteLine(item);
            //}

            List<int> list = new List<int>() { 1, 2, 3, -4, -5, 6, 7, -8, 9 };

            IEnumerable<int> result = list.Filter(x => x > 1);

            foreach (int item in result)
            {
                Console.WriteLine(item);
            }

            list[1] = -10;
            Console.WriteLine("---------------------------------");

            foreach (int item in result)
            {
                Console.WriteLine(item);
            }
        }
    }
}
