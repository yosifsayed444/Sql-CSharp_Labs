﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day8
{
    internal static class Extensions
    {
        public static IEnumerable<T> Filter<T>(this IEnumerable<T> collection, Predicate<T> predicate)
        {
            //List<T> result = new List<T>();

            foreach (T item in collection)
            {
                if (predicate(item))
                    //result.Add(item);
                    yield return item;
            }

           // return result;
        }


        public static void PrintMe(this int num)
        {
            Console.WriteLine(num);
        }

        public static int GetumberOfSpaces(this string str)
        {
            int counter = 0;

            for (int i = 0; i < str.Length; i++)
            {
                if(str[i] == ' ')
                    counter++;
            }

            return counter;
        }

        public static string RemoveCharacter(this string str, char ch)
        {
            return "";
        }
    }
}
