﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Day7
{
    internal class Program
    {
        static bool finished = false;

        static void Main(string[] args)
        {
            #region Thread
            //ThreadStart threadStart = new ThreadStart(PrintY);
            //Thread thread = new Thread(PrintY);

            //try
            //{
            //    Thread thread = new Thread(() => PrintY(1000));
            //    //thread.IsBackground = true;
            //    thread.Start();
            //}
            //catch(Exception ex)
            //{

            //}

            //for (int i = 0; i < 1000; i++)
            //{
            //    if (i > 500)
            //        thread.Join();

            //    //thread.Abort();
            //    Console.Write("X");
            //}
            //thread.Join(10);

            //Thread t1 = new Thread(Finish);

            //t1.Start();
            //Finish(); 
            #endregion


            RunThreadAsync();

            for (int i = 0; i < 100000; i++)
            {
                Console.Write("X");
            }

            //task.Wait();
            //int number = task.Result;
        }

        private static async void RunThreadAsync()
        {
            //Task<int> task = Task<int>.Run(() => PrintY(1000));

            //task.GetAwaiter().OnCompleted(Test);
            //task.GetAwaiter().OnCompleted(() => PrintResult(task.Result));

            //task.GetAwaiter().OnCompleted(() => Console.WriteLine($"\nCounter  = {task.Result}"));

            int counter = await Task<int>.Run(() => PrintY(1000));
            Console.WriteLine($"\nCounter  = {counter}");

        }

        static void Test()
        {
            Console.WriteLine("Task is finished");
        }

        static void PrintResult(int counter)
        {
            Console.WriteLine($"\nCounter  = {counter}");
        }

        static int PrintY(int maxNumber)
        {
            //throw new NotImplementedException();

            int counter = 0;
            for (int i = 0; i < maxNumber; i++)
            {
                if (i % 2 == 0)
                    counter++;

                //Thread.Sleep(1000);

                Console.Write("Y");
            }

            return counter;
        }

        static void Finish()
        {
            if(!finished)
            {
                Console.WriteLine("Finished");
                finished = true;
            }
        }
    }
}
