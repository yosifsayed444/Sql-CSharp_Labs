﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UIThreading
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void StartCounting(int maxNumber)
        {
            int counter = 0;

            for (int i = 0; i < maxNumber; i++)
            {
                for (int j = 0; j < maxNumber; j++)
                {
                    counter++;
                }

                Action action = () => UpdateTxtCounter(counter);
                this.Invoke(action);
            }
        }

        private void UpdateTxtCounter(int counter)
        {
            try
            {
                txtCounter.Text = counter.ToString();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            try
            {
                Task.Run(() => StartCounting(10000));
            }
            catch(Exception ex)
            {

            }
        }
    }
}
