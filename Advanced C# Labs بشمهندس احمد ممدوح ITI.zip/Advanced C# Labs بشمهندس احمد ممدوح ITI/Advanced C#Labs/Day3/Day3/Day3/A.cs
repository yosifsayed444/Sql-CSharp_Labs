﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3
{
    internal class A
    {
        int x;

        class B
        {
            public B(A a)
            {
                a.x = 3;
            }
        }
    }
}
