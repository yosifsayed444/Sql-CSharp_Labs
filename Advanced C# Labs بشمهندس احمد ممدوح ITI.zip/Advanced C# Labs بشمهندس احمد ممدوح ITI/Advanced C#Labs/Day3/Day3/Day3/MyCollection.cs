﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3
{
    internal class MyCollection<T> : IEnumerable where T : class  // where T : new () 
    {
        T[] arr;
        int currentIndex;

        public MyCollection()
        {
            arr = new T[5];
            currentIndex = -1;
        }

        public T this[int index]
        {
            get
            {
                return arr[index];
            }

            set
            {
                arr[index] = value;
            }
        }

        public T this[string str]
        {
            get
            {
                for (int i = 0; i < arr.Length; i++)
                {
                    if(arr[i].ToString() == str)
                        return arr[i];
                }

                return null;
            }
        }

        //public T this[int x, string y, float z]
        //{

        //}

        public void Add(T item)
        {
            if(currentIndex == arr.Length - 1)
            {
                Extend();
            }

            currentIndex++;
            arr[currentIndex] = item;
        }

        private void Extend()
        {
            T[] newArr = new T[arr.Length * 2];

            for (int i = 0; i < arr.Length; i++)
            {
                newArr[i] = arr[i];
            }

            arr = newArr;
        }

        public T GetByIndex(int index)
        {
            return arr[index];
        }

        public IEnumerator GetEnumerator()
        {
            return new Iterator<T>(this);
        }

        class Iterator<T> : IEnumerator where T : class
        {
            MyCollection<T> myCollection;
            int index = -1;

            public Iterator(MyCollection<T> myCollection)
            {
                this.myCollection = myCollection;
            }

            public object Current
            {
                get
                {
                    return myCollection.arr[index];
                }
            }

            public bool MoveNext()
            {
                index++;

                return index <= myCollection.currentIndex;
            }

            public void Reset()
            {
                index = -1;
            }
        }
    }
}
