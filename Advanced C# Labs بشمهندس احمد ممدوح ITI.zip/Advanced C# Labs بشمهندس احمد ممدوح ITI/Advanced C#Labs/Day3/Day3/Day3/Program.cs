﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            MyCollection<Employee> employees = new MyCollection<Employee>();

            employees.Add(new Employee { ID = 1, Name = "Ali" });
            employees.Add(new Employee { ID = 2, Name = "Hosam" });
            employees.Add(new Employee { ID = 3, Name = "Medhat" });

            #region IEnumerable
            //IEnumerator enumerator = employees.GetEnumerator();

            //while(enumerator.MoveNext())
            //{
            //    Employee emp = (Employee)enumerator.Current;
            //    Console.WriteLine(emp);
            //}

            //foreach (Employee emp in employees)
            //{
            //    Console.WriteLine(emp);
            //} 
            #endregion

            #region Indexer
            // Employee emp = employees[0]; //employees.GetByIndex(0);
            //Employee emp = employees["dhfjksdf"]; 
            #endregion

            string s1 = "Hello";
            string s2 = Console.ReadLine();

            Employee e1 = new Employee { ID = 1, Name = "Ali" };
            Employee e2 = new Employee { ID = 1, Name = "Ali" };

            //s1 += "ITI";

            //Console.WriteLine(s1.GetHashCode());
            //Console.WriteLine(s2.GetHashCode());

            Console.WriteLine(object.ReferenceEquals(s1, e1.Name));

            s1 += "ITI";
            Console.WriteLine(s1.GetHashCode());

            Console.WriteLine(s1);
        }

        private static void Test(string s1)
        {
            s1 += "test";
            Console.WriteLine(s1);
        }
    }
}
