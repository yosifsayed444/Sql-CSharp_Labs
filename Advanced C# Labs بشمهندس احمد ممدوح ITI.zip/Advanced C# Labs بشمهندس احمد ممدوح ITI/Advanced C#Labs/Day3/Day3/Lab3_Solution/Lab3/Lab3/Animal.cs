﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Lab3
{
    internal class Zoo : IEnumerable<Animal>
    {
        private List<Animal> animals = new List<Animal>();

        public void Add(Animal animal) => animals.Add(animal);

        public IEnumerator<Animal> GetEnumerator()
        {
            return animals.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }

    internal class Animal 
    {
        public int Age { get; set; }

        public Animal(int age)
        {
            if (age > 0 && age < 10)
                Age = age;
            else
                throw new Exception("Invalid age");

        }
    }
    internal class Lion : Animal
    {
        public Lion(int age) : base(age)
        {
        }
        public override string ToString() => $"this is a lion with age {Age}";
        
    }

    internal class Sparrow : Animal
    {
        public Sparrow(int age) : base(age)
        {
            
        }
        public override string ToString() => $"this is a sparrow with age {Age}";
    }

    internal class Piegon : Animal
    {
        public Piegon(int age) : base(age)
        {
        }
        public override string ToString() => $"this is a piegon with age {Age}";
    }
}
