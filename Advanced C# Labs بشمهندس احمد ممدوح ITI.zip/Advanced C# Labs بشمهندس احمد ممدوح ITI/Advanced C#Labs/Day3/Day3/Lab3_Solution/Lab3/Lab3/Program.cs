﻿namespace Lab3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Zoo zoo = new Zoo();
            //zoo.Add(new Lion(2));
            //zoo.Add(new Sparrow(3));
            //zoo.Add(new Piegon(4));

            //foreach (Animal animal in zoo)
            //{
            //    Console.WriteLine(animal.ToString());

            //}

            PhoneBook phoneBook = new PhoneBook();
            phoneBook[123] = "Ali"; 
            phoneBook["Hosam"] = 456; 
            int phone = phoneBook["Ali"]; 
            Console.WriteLine(phone);


        }
    }
}
