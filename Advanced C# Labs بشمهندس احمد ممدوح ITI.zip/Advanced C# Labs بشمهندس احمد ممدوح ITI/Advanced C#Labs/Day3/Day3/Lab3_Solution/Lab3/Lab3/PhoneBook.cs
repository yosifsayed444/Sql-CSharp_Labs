﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Linq;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Lab3
{
    internal class PhoneBook 
    {
        public List<PhoneBookEntry> entries = new List<PhoneBookEntry>(); // <PhoneBookEntry>

        public string this[int index]
        {
            get
            {
                foreach(var entry in entries)
                {
                    if (entry.Number == index)
                        return entry.Name;
                }

                return null;
            }
            set { entries.Add(new PhoneBookEntry { Number = index, Name = value }); }
        }

        public int this[string name]
        {
            get
            {
                foreach (var entry in entries)
                {
                    if (entry.Name == name)
                        return entry.Number;
                }

                return -1;
            }
            set { entries.Add(new PhoneBookEntry { Number = value, Name = name }); }
        }
    }
    public class PhoneBookEntry
    {
        public string Name { get; set; }
        public int Number { get; set; }
    }
}
