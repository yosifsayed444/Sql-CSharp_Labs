﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2
{
    internal class MyCollection<T> //where T : new ()
    {
        T[] arr;
        int currentIndex;

        public MyCollection()
        {
            arr = new T[5];
            currentIndex = -1;
        }

        public void Add(T item)
        {
            if(currentIndex == arr.Length - 1)
            {
                Extend();
            }

            currentIndex++;
            arr[currentIndex] = item;
        }

        private void Extend()
        {
            T[] newArr = new T[arr.Length * 2];

            for (int i = 0; i < arr.Length; i++)
            {
                newArr[i] = arr[i];
            }

            arr = newArr;
        }

        public T GetByIndex(int index)
        {
            return arr[index];
        }
    }
}
