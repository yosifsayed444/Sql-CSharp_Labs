﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region Object initializer
            //Employee e1 = new Employee() { ID = 10, Name = "Ali" };
            //e1.ID = 10;
            //e1.Name = "Ali"; 
            #endregion

            #region Generics
            //MyCollection<int> myCollection = new MyCollection<int>();

            //MyCollection<string> myCollection2 = new MyCollection<string>();

            //myCollection.Add(1);
            //myCollection.Add(2);
            ////myCollection.Add("dfsdfdf");
            ////myCollection.Add(new Employee());

            //myCollection2.Add("hello");

            //int x = myCollection.GetByIndex(0); 
            #endregion

            //int[] arr = { 4, 3, 1, 5, 8 };

            Employee e1 = new Employee { ID = 1 , Name = "test"};

            //if(e1.CompareTo("tttttt") == 0)
            //    Console.WriteLine("Equals");
            //else
            //    Console.WriteLine("Not equal");
            
            Employee[] emps = new Employee[]
            {
                new Employee { ID = 2, Name = "Ali"},
                new Employee { ID = 1, Name = "Medhat"},
                new Employee { ID = 3, Name = "Hosam"},
            };
            
            Array.Sort(emps);

            for (int i = 0; i < emps.Length; i++)
            {
                Console.WriteLine(emps[i]);
            }

        }
    }
}
