﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab2_Solution
{
    internal class Trainee : IPayable, IComparer<Trainee>
    {
        public int ID { get; set; }
        public string Name { get; set; }

        public decimal Salary { get; set; }

        public Trainee(int s)
        {
            Salary = s;
        }
        public override string ToString()
        {
            return $"ID: {ID} \t Name: {Name}";
        }
        public void ShowPayment()
        {
            Console.WriteLine(Salary);
        }
        public int Compare(Trainee? x, Trainee? y)
        {
            if (x == null && y == null)
                return 0;

            if (x == null)
                return -1;

            if (y == null)
                return 1;

            return x.Salary == y.Salary ? 1 : -1 ;

        }
    }
}
