﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab2_Solution
{
    interface IPayable
    {
        decimal Salary { get; set; }
        void ShowPayment();
    }
}
