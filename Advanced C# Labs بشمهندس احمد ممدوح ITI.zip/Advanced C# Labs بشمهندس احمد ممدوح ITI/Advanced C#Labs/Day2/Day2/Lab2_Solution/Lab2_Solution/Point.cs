﻿using System;

namespace Lab2_Solution
{
    internal class Point : IComparable<Point>, ICloneable
    {
        public int X { get; set; }
        public int Y { get; set; }

        public Point(int x, int y)
        {
            X = x;
            Y = y;
        }

        public void Display()
        {
            Console.WriteLine($"Coordinates are ({X}, {Y})");
        }

        public void ChangeCoordinates(int newX, int newY)
        {
            X = newX;
            Y = newY;
        }

        public int CompareTo(Point? p)
        {
            if (p == null)
                return 1;

            return X.CompareTo(p.X);
        }

        public override string ToString()
        {
            return $"({X}, {Y})";
        }

        public object Clone()
        {
            return new Point(X, Y);
        }
    }
}