﻿namespace Lab2_Solution
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Point[] points = new Point[] {
                new Point (10,20),
                new Point (30,20),
                new Point (9,20)

            };

            Array.Sort(points);

            for (int i = 0; i < points.Length; i++)
            {
                Console.WriteLine(points[i]);
            }

            Point p1 = new Point(10, 20);

            Point p2 = (Point)p1.Clone();

            p2.X = 100;

            p1.Display();
            p2.Display();

            Trainee t1 = new Trainee(5000);
            Trainee t2 = new Trainee(3000);

            Trainee comparer = new Trainee(0);

            int result = comparer.Compare(t1, t2);

            Console.WriteLine(result);

        }   
    }
}

