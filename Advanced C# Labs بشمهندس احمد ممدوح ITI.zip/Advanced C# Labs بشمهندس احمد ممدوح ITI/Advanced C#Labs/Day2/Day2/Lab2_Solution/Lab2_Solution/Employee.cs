﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab2_Solution
{
    internal class Employee : IComparable<Employee>, IPayable
    {
        public int ID { get; set; }
        public string Name { get; set; }

        public decimal Salary { get; set; }


        public int CompareTo(Employee emp)
        {
            return this.ID.CompareTo(emp.ID);
        }

        public override string ToString()
        {
            return $"ID: {ID} \t Name: {Name}";
        }
        public void ShowPayment()
        {
            Console.WriteLine(Salary);
        }
    }
}