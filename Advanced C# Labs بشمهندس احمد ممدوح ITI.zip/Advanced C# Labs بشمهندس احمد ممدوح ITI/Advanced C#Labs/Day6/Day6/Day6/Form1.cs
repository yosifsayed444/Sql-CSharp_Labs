﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Day6
{
    public partial class Form1 : Form
    {
        List<Continent> continents;

        public Form1()
        {
            InitializeComponent();

            continents = new List<Continent>
            {
                new Continent { ID = 1, Name = "Africa"},
                new Continent { ID = 2, Name = "Asia"},
                new Continent { ID = 3, Name = "Europe"},
            };

            FillCmbContinents();

            //Text = "Hellooooooooo";
            //sBackColor = Color.BlueViolet;
            //ClientSize = new Size(100, 100);

            //this.Load += Form1_Load;
            //this.MouseMove += Form1_MouseMove;

            //Button btn = new Button();
            //btn.Text = "Click Me";
            //btn.Location = new Point(20, 40);

            //btn.Click += Btn_Click;

            //this.Controls.Add(btn);
        }

        private void FillCmbContinents()
        {
            //cmbContinents.Items.Add("Africa");
            //cmbContinents.Items.Add("Asia");
            //cmbContinents.Items.Add("Europe");

            //string[] continents = new string[]
            //{
            //    "Africa", "Asia", "Europe"
            //};

            //cmbContinents.Items.AddRange(continents);

            cmbContinents.DisplayMember = "Name";
            //cmbContinents.Items.AddRange(continents.ToArray());
            //cmbContinents.SelectedIndex = 0;

            cmbContinents.DataSource = continents;

            dataGridView1.DataSource = continents;
        }

        //private void Btn_Click(object sender, EventArgs e)
        //{
        //    BackColor = Color.DarkOliveGreen;
        //}

        private void Form1_Load(object sender, EventArgs e)
        {
            btnMsg.Text = "Please click here";
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            Text = $"X = {e.X} \t Y = {e.Y}";
            //BackColor = Color.FromArgb(e.X % 255, e.Y % 255, e.X / 255);
        }

        private void btnMsg_Click(object sender, EventArgs e)
        {
            //lblMsg.Visible = false;

            lblMsg.Text = txtMsg.Text;

            //cmbContinents.Items.Add(txtMsg.Text);
            //cmbContinents.Items.Clear();

            continents.Add(new Continent { ID = 4, Name = txtMsg.Text });
            cmbContinents.DataSource = null;
            cmbContinents.DataSource = continents;
            cmbContinents.DisplayMember = "Name";
        }

        private void lblMsg_MouseEnter(object sender, EventArgs e)
        {
            lblMsg.ForeColor = Color.Red;
        }

        private void lblMsg_MouseLeave(object sender, EventArgs e)
        {
            lblMsg.ForeColor = Color.Black;
        }

        private void txtMsg_TextChanged(object sender, EventArgs e)
        {
            lblMsg.Text = txtMsg.Text;
        }

        private void cmbContinents_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbContinents.SelectedIndex == -1)
                return;

            Continent continent = cmbContinents.SelectedItem as Continent;
            lblMsg.Text = $"ID: {continent.ID} \t Name: {continent.Name}";
        }

        //public void Form1_Load(object sender, EventArgs e)
        //{

        //}
    }
}
