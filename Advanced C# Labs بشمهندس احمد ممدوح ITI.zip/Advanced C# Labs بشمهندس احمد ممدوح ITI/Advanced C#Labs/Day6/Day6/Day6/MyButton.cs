﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Day6
{
    public partial class MyButton : Control
    {
        public MyButton()
        {
            InitializeComponent();

            this.MouseEnter += MyButton_MouseEnter;
            this.MouseLeave += MyButton_MouseLeave;
        }

        private void MyButton_MouseLeave(object sender, EventArgs e)
        {
            Graphics gr = this.CreateGraphics();
            gr.FillRectangle(Brushes.Red, 0, 0, this.Width, this.Height);
        }

        private void MyButton_MouseEnter(object sender, EventArgs e)
        {
            Graphics gr = this.CreateGraphics();
            gr.FillRectangle(Brushes.Yellow, 0, 0, this.Width, this.Height);
        }

        protected override void OnPaint(PaintEventArgs pe)
        {
            base.OnPaint(pe);

            pe.Graphics.FillRectangle(Brushes.Red, 0, 0, this.Width, this.Height);
        }
    }
}
