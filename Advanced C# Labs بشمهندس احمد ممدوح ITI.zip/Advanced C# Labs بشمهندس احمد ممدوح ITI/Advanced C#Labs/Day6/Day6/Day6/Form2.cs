﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Day6
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Paint(object sender, PaintEventArgs e)
        {
            //e.Graphics.DrawRectangle(Pens.Red, 10, 10, 100, 200);
            // e.Graphics.FillRectangle(Brushes.Red, 100, 100, 80, 50);

            GraphicsPath graphicsPath = new GraphicsPath();
            graphicsPath.AddRectangle(new Rectangle(10, 10, 100, 100));
            graphicsPath.AddEllipse(new Rectangle(300, 300, 50, 50));

            this.Region = new Region(graphicsPath);
        }

        private void btnDraw_Click(object sender, EventArgs e)
        {
            //Graphics gr = this.CreateGraphics();

            //gr.FillRectangle(Brushes.Red, 300, 300, 50, 80);
        }

        private void Form2_MouseMove(object sender, MouseEventArgs e)
        {
            Graphics gr = this.CreateGraphics();

            //if (e.Button == MouseButtons.Left)
            //{
            //    Graphics gr = this.CreateGraphics();
            //    gr.FillEllipse(Brushes.Red, e.X, e.Y, 10, 10);
            //}

            //if ((e.X >= 100 && e.X <= 180) && (e.Y >= 100 && e.Y <= 150))
            //{
            //    gr.FillRectangle(Brushes.Yellow, 100, 100, 80, 50);
            //}
            //else
            //{
            //    gr.FillRectangle(Brushes.Red, 100, 100, 80, 50);
            //}
        }

        private void Form2_MouseClick(object sender, MouseEventArgs e)
        {
            //if ((e.X >= 100 && e.X <= 180) && (e.Y >= 100 && e.Y <= 150))
            //{
            //    this.Text = "Hello ITI";
            //}
        }

        private void myButton1_Click(object sender, EventArgs e)
        {
            BackColor = Color.DarkOliveGreen;
        }
    }
}
