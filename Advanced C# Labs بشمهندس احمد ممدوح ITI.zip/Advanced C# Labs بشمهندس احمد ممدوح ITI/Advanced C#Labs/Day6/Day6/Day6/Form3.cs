﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Day6
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btnOpenForm_Click(object sender, EventArgs e)
        {
            FrmMsg frmMsg = new FrmMsg();
            frmMsg.Msg = txtInfo.Text;

            frmMsg.TextChanged += FrmMsg_MsgChanged;

            frmMsg.Show();
        }

        private void FrmMsg_MsgChanged(object sender, EventArgs e)
        {
            FrmMsg frmMsg = sender as FrmMsg;

            txtInfo.Text = frmMsg.Msg;
        }
    }
}
