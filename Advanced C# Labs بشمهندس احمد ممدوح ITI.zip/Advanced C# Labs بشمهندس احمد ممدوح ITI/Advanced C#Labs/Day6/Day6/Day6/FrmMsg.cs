﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Day6
{
    public partial class FrmMsg : Form
    {
        public event EventHandler MsgChanged;

        public FrmMsg()
        {
            InitializeComponent();
        }

        public string Msg
        {
            set
            {
                txtMsg.Text = value;
            }

            get
            { return txtMsg.Text; }
        }

        private void txtMsg_TextChanged(object sender, EventArgs e)
        {
            if(MsgChanged != null)
                MsgChanged(this, new EventArgs());
        }
    }
}
